from django.shortcuts import redirect, render
from django.contrib.auth import login, logout, authenticate
from .models import UserProfile, Services, Partners, OrderPlan, Orders
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.http import HttpResponse
from owner.models import offer
import decimal
import math
import random
from django.conf import settings
from django.core.mail import send_mail
from django.contrib import messages


def home(request):
    if request.method == 'POST':
        if 'searchBarButton' in request.POST:
            search = request.POST['searchBar']

        elif 'loginButton' in request.POST:
            mailid = request.POST['email']
            pswd = request.POST['pswd']
            try:
                u = authenticate(username=User.objects.get(
                    email=mailid), password=pswd)
                user_type = UserProfile.objects.get(user=u.id)
                if u:
                    login(request, u)
                    if user_type.user_type == 'Admin':
                        return redirect('/admin/dashboard/')
                    elif user_type.user_type == 'Customer':
                        return redirect('/customer/dashboard/')
                    elif user_type.user_type == 'Partner':
                        return redirect('/partner/dashboard/')
                else:
                    return HttpResponse('<h1>404</h1')
            except:
                return HttpResponse("<h1>User Not Found</h1><br><br><br><a href=''>Go Back</a>")

        elif 'regesterButton' in request.POST:

            fname = request.POST['fname']
            lname = request.POST['lname']
            uname = request.POST['uname']
            email = request.POST['email']
            pswd = request.POST['pswd']
            contact_no = request.POST['mob']

            userobj = User(first_name=fname, last_name=lname, username=uname,
                           email=email, password=make_password(pswd))
            userobj.save()

            user_profile = UserProfile(
                user_contact=contact_no, user_id=userobj.id)
            user_profile.save()

            return redirect('/')

    uobj = User.objects.latest('id')
    serobj = Services.objects.all().order_by('servicename')
    offerobj = offer.objects.all()

    data = {
        'uobj': uobj,
        'service': serobj,
        'offer': offerobj
    }

    return render(request, 'index.html', data)


def log_in(request):

    return render(request, 'login.html')


def log_out(request):
    logout(request)
    return redirect('/')


def addPartner(request):

    serviceobj = Services.objects.all()
    if request.method == 'POST':
        pname = request.POST['partname']
        contact = request.POST['contact']
        email = request.POST['email']
        pswd = request.POST['pswd']
        address = request.POST['address']
        city = request.POST['city']
        state = request.POST['state']
        partimg = request.FILES['partimg']
        servicetype = request.POST['servicetype']
        adhar = request.POST['adhar']
        fname = pname.split(' ')[0]
        lname = ' '.join(pname.split(' ')[1:])
        latest = User.objects.latest('id')
        Id = latest.id
        Id = Id+1
        uname = fname+str(Id)
        flag = False
        preuser = None
        uobj = User.objects.all()
        for i in uobj:
            if i.email == email:
                flag = True
                preuser = i.id
                break
            else:
                flag = False

        if flag == False:
            u = User(first_name=fname, last_name=lname, email=email,
                     password=make_password(pswd), username=uname)
            u.save()
            up = UserProfile(user_type='Partner',
                             user_contact=contact, user=u)
            up.save()
            servtype = Services.objects.get(id=int(servicetype))
            partobj = Partners(partname=pname, partemail=email, partpswd=pswd,
                               partcontact=contact, partaddress=address, city=city, state=state, user=up, service=servtype, partimg=partimg, aadharNo=adhar)
            partobj.save()

            return redirect('/')

        else:
            pass

        return redirect('/addpartner/')

    return render(request, 'addpartner.html', {'service': serviceobj})


def detailsPage(request, page):
    tab = ''
    uobj = User.objects.latest('id')
    serobj = Services.objects.all().order_by('servicename')
    offerobj = offer.objects.all()
    try:
        uprofile = UserProfile.objects.get(id=request.user.id)
        if uprofile.user_type == 'Admin':
            tab = 'admin.html'
        elif uprofile.user_type == 'Customer':
            tab = 'login.html'
        else:
            tab = 'index.html'
    except:
        tab = 'index.html'
    data = {
        'tab': tab,
        'uobj': uobj,
        'service': serobj,
        'offer': offerobj,
        'page': page,
    }
    return render(request, 'detail.html', data)


def billGenerator(request, id):

    order = Orders.objects.get(id=id)
    address = order.address
    address = address.split(',')
    plan = []
    oplan = OrderPlan.objects.filter(order=order)
    price = 0.0
    for i in oplan:
        price = decimal.Decimal(price) + i.price

    tax = order.total_amount-price
    data = {
        'order': order,
        'address': address,
        'plan': oplan,
        'tax_amt': tax
    }
    return render(request, 'billInvoice.html', data)


otp = ''
for i in range(6):
    otp += str(random.randint(0, 9))


def forgotpaswd(request, value):
    mail = ''
    if request.method == 'POST':
        if 'email' in request.POST:
            mail = request.POST['emailid']
            try:
                uobj = User.objects.get(email=mail)
                if uobj:
                    send_mail(
                        'Password Reset Code',
                        'Here is your Verifiaction Code \n {}'.format(otp),
                        settings.EMAIL_HOST_USER,
                        [mail]
                    )
            except:
                pass
            value = 'verification'
            return redirect('/forgot_password/verification/')

        elif 'otp' in request.POST:
            code = request.POST['otp']
            mail = request.POST['mail']
            if code == otp:
                value = 'pswd_reset'
                return redirect('/forgot_password/pswd_reset/')

            else:
                messages.error(request, 'Invalid OTP')
                value = 'verification'
                return redirect('/forgot_password/verification/')

        elif 'pass1' in request.POST:
            mail = request.POST['mail']
            pswd1 = request.POST['pass1']
            pswd2 = request.POST['pass2']
            if pswd1 == pswd2:
                uobj = User.objects.filter(email=mail)
                uobj.update(password=make_password(pswd1))
                messages.success(request, 'Password Changed')
                return redirect('/')

            else:
                messages.error(request, 'passwords dont match')
                return redirect('/forgot_password/pswd_reset/')

    data = {
        'value': value,
        'code': otp,
        'mail': mail,
    }
    return render(request, 'forgot.html', data)
