from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    user_type = models.CharField(max_length=50, default='Customer')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    user_contact = models.CharField(max_length=15)
    uspoints = models.IntegerField(default=0)
    dateJoined = models.DateField(auto_now=True)


class Services(models.Model):
    servicename = models.CharField(max_length=50)
    serviceimg = models.ImageField(upload_to="serviceimg", blank=True)


class Category(models.Model):
    name = models.CharField(max_length=50)
    service = models.ForeignKey(Services, on_delete=models.CASCADE)


class ServicePlans(models.Model):
    planname = models.CharField(max_length=50)
    service = models.ForeignKey(Services, on_delete=models.CASCADE)
    planprice = models.DecimalField(max_digits=10, decimal_places=2)
    planimg = models.ImageField(upload_to="plans", blank=True)
    cat = models.ForeignKey(Category, on_delete=models.CASCADE)


class Partners(models.Model):
    partname = models.CharField(max_length=50)
    partemail = models.CharField(max_length=50)
    partpswd = models.CharField(max_length=50)
    partcontact = models.CharField(max_length=50)
    partaddress = models.CharField(max_length=100)
    city = models.CharField(max_length=50, default=None)
    state = models.CharField(max_length=50, default=None)
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    partimg = models.ImageField(upload_to="partnerimg", blank=True)
    service = models.ForeignKey(Services, on_delete=models.CASCADE)
    completed_service = models.IntegerField(default=0)
    rating = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)
    aadharNo = models.CharField(max_length=14, default=None)


class Orders(models.Model):
    orderID = models.CharField(max_length=16, unique=True)
    placed_by = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField(auto_now=True)
    address = models.CharField(max_length=100)
    date_of_service = models.DateField(null=True)
    status = models.CharField(max_length=50, default='Pending')
    partner = models.ForeignKey(Partners, on_delete=models.CASCADE, null=True)


class OrderPlan(models.Model):
    order = models.ForeignKey(Orders, on_delete=models.CASCADE)
    serviceplan = models.ForeignKey(ServicePlans, on_delete=models.CASCADE)
    service = models.ForeignKey(Services, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)


class Cart(models.Model):
    class Meta():
        unique_together = ('service', 'plan', 'user')
    service = models.ForeignKey(Services, on_delete=models.CASCADE)
    plan = models.ForeignKey(ServicePlans, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
