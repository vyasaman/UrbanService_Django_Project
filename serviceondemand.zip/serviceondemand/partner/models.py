from django.db import models
from serviceondemand.models import Orders, ServicePlans, Partners

# Create your models here.


class WorkRequest(models.Model):
    partner = models.ForeignKey(Partners, on_delete=models.CASCADE)
    orderId = models.ForeignKey(Orders, on_delete=models.CASCADE)
    servicePlan = models.ForeignKey(ServicePlans, on_delete=models.CASCADE)
