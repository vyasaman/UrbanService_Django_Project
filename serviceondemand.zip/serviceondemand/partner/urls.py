from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.home),
    path('requestaccept/<int:id>/<int:order>/<int:req>/', views.requestaccept),
    path('withdraw/<int:id>/', views.withdraw),
    path('completed/<int:id>/<str:amount>/<int:order>/', views.completed),

]
