from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from owner.models import offer
from .models import WorkRequest
from serviceondemand.models import Partners, UserProfile, Orders, ServicePlans
from datetime import datetime
from django.contrib import messages
import pdfkit
from django.core.mail import EmailMessage
from django.conf import settings


# Create your views here.


@login_required(login_url='/')
def home(request):
    x = datetime.now()
    a = x.month
    b = x.year
    uobj = UserProfile.objects.get(user=request.user)
    part = Partners.objects.get(user=uobj)

    wobj = WorkRequest.objects.filter(
        partner=part)
    req = []
    serv = []
    for i in wobj:

        if i.orderId in req:
            continue
        else:
            req.append(Orders.objects.get(id=i.orderId_id))

    ordobj = []
    for i in range(1, a+1):
        ordobj.append(str(Orders.objects.filter(
            date_of_service__month=str(i), date_of_service__year=str(b), status='Completed', partner=part).count()))
    ordobj = ' '.join(ordobj)
    print(ordobj)
    uprofile = UserProfile.objects.get(id=part.user_id)
    data = {
        'req': req,
        'service': wobj,
        'part': part,
        'userprofile': uprofile,
        'done': ordobj,
    }

    return render(request, 'partner.html', data)


def requestaccept(request, id, order, req):
    if req == 0:
        wobj = WorkRequest.objects.filter(orderId=order).exclude(
            partner=Partners.objects.get(id=id))
        wobj.delete()
        ord = Orders.objects.filter(id=order)
        ord.update(status='Accepted', partner=Partners.objects.get(id=id))
        pdfkit.from_url(
            "http://localhost:8000/bill_invoice/{}/".format(order), 'd:/My data/records/abc.pdf')
        mail = EmailMessage(
            'Your Booking Is Confirmed',
            'Your Order From Urban Service Is been Accepted By the Partner. For More Details Check the Document attached with this mail.',
            settings.EMAIL_HOST_USER,
            ['gaming.atlyas@gmail.com']
        )
        mail.attach_file('d:/My data/records/abc.pdf')
        mail.send()
        return redirect('/partner/dashboard/')

    else:
        print(id)
        wobj = WorkRequest.objects.filter(
            orderId=Orders.objects.get(id=order), partner=Partners.objects.get(id=id))
        wobj.delete()
        workobj = WorkRequest.objects.filter(orderId=order).count()
        if workobj > 0:
            pass
        else:
            ord = Orders.objects.filter(id=order)
            ord.update(status='Rejected')

    return redirect('/partner/dashboard/')


def withdraw(request, id):
    acc_sum = UserProfile.objects.get(id=Partners.objects.get(id=id).user_id)
    if acc_sum.uspoints < 1000:
        messages.error(request, 'Insufficient Balance')
        return redirect('/partner/dashboard/')
    else:

        return render(request, 'serviceRequest.html')


def completed(request, id, amount, order):
    ord = Orders.objects.filter(id=order)
    ord.update(status='Completed', partner=Partners.objects.get(id=id))
    wobj = WorkRequest.objects.filter(
        orderId=Orders.objects.get(id=order), partner=Partners.objects.get(id=id))
    wobj.delete()
    workdone = Orders.objects.filter(
        status='Completed', partner=Partners.objects.get(id=id)).count()
    acc = Partners.objects.filter(id=id)
    acc.update(completed_service=workdone)
    upobj = UserProfile.objects.filter(id=Partners.objects.get(id=id).user_id)
    amount = float(amount)-(float(amount)*0.3)
    for i in upobj:
        amount += i.uspoints

    upobj.update(uspoints=amount)
    return redirect('/partner/dashboard/')
