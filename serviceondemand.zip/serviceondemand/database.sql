-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.22 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for urbanservice
CREATE DATABASE IF NOT EXISTS `urbanservice` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `urbanservice`;

-- Dumping structure for table urbanservice.auth_group
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_group: ~0 rows (approximately)
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;

-- Dumping structure for table urbanservice.auth_group_permissions
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_group_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;

-- Dumping structure for table urbanservice.auth_permission
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_permission: ~56 rows (approximately)
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
	(1, 'Can add log entry', 1, 'add_logentry'),
	(2, 'Can change log entry', 1, 'change_logentry'),
	(3, 'Can delete log entry', 1, 'delete_logentry'),
	(4, 'Can view log entry', 1, 'view_logentry'),
	(5, 'Can add permission', 2, 'add_permission'),
	(6, 'Can change permission', 2, 'change_permission'),
	(7, 'Can delete permission', 2, 'delete_permission'),
	(8, 'Can view permission', 2, 'view_permission'),
	(9, 'Can add group', 3, 'add_group'),
	(10, 'Can change group', 3, 'change_group'),
	(11, 'Can delete group', 3, 'delete_group'),
	(12, 'Can view group', 3, 'view_group'),
	(13, 'Can add user', 4, 'add_user'),
	(14, 'Can change user', 4, 'change_user'),
	(15, 'Can delete user', 4, 'delete_user'),
	(16, 'Can view user', 4, 'view_user'),
	(17, 'Can add content type', 5, 'add_contenttype'),
	(18, 'Can change content type', 5, 'change_contenttype'),
	(19, 'Can delete content type', 5, 'delete_contenttype'),
	(20, 'Can view content type', 5, 'view_contenttype'),
	(21, 'Can add session', 6, 'add_session'),
	(22, 'Can change session', 6, 'change_session'),
	(23, 'Can delete session', 6, 'delete_session'),
	(24, 'Can view session', 6, 'view_session'),
	(25, 'Can add cart', 7, 'add_cart'),
	(26, 'Can change cart', 7, 'change_cart'),
	(27, 'Can delete cart', 7, 'delete_cart'),
	(28, 'Can view cart', 7, 'view_cart'),
	(29, 'Can add category', 8, 'add_category'),
	(30, 'Can change category', 8, 'change_category'),
	(31, 'Can delete category', 8, 'delete_category'),
	(32, 'Can view category', 8, 'view_category'),
	(33, 'Can add order plan', 9, 'add_orderplan'),
	(34, 'Can change order plan', 9, 'change_orderplan'),
	(35, 'Can delete order plan', 9, 'delete_orderplan'),
	(36, 'Can view order plan', 9, 'view_orderplan'),
	(37, 'Can add orders', 10, 'add_orders'),
	(38, 'Can change orders', 10, 'change_orders'),
	(39, 'Can delete orders', 10, 'delete_orders'),
	(40, 'Can view orders', 10, 'view_orders'),
	(41, 'Can add partners', 11, 'add_partners'),
	(42, 'Can change partners', 11, 'change_partners'),
	(43, 'Can delete partners', 11, 'delete_partners'),
	(44, 'Can view partners', 11, 'view_partners'),
	(45, 'Can add service plans', 12, 'add_serviceplans'),
	(46, 'Can change service plans', 12, 'change_serviceplans'),
	(47, 'Can delete service plans', 12, 'delete_serviceplans'),
	(48, 'Can view service plans', 12, 'view_serviceplans'),
	(49, 'Can add services', 13, 'add_services'),
	(50, 'Can change services', 13, 'change_services'),
	(51, 'Can delete services', 13, 'delete_services'),
	(52, 'Can view services', 13, 'view_services'),
	(53, 'Can add user profile', 14, 'add_userprofile'),
	(54, 'Can change user profile', 14, 'change_userprofile'),
	(55, 'Can delete user profile', 14, 'delete_userprofile'),
	(56, 'Can view user profile', 14, 'view_userprofile'),
	(57, 'Can add offer', 15, 'add_offer'),
	(58, 'Can change offer', 15, 'change_offer'),
	(59, 'Can delete offer', 15, 'delete_offer'),
	(60, 'Can view offer', 15, 'view_offer'),
	(61, 'Can add work request', 16, 'add_workrequest'),
	(62, 'Can change work request', 16, 'change_workrequest'),
	(63, 'Can delete work request', 16, 'delete_workrequest'),
	(64, 'Can view work request', 16, 'view_workrequest'),
	(65, 'Can add account summary', 17, 'add_accountsummary'),
	(66, 'Can change account summary', 17, 'change_accountsummary'),
	(67, 'Can delete account summary', 17, 'delete_accountsummary'),
	(68, 'Can view account summary', 17, 'view_accountsummary');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;

-- Dumping structure for table urbanservice.auth_user
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_user: ~5 rows (approximately)
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
	(1, 'pbkdf2_sha256$120000$SCAaVCUoZVlo$FidYXmEiKcW+poWAPc3KMj/OQigtfSmT29AAGtkvVaI=', '2021-06-25 15:27:31.350144', 1, 'amanv0', 'Aman', 'Vyas', 'amanvyas720@gmail.com', 1, 1, '2021-06-11 06:37:09.916857'),
	(2, 'pbkdf2_sha256$120000$1UcxZmec9UXf$O3sPiq0Nax1iQtOu1QD+M5vHBhYOhqGlMkDVnCb/T5U=', '2021-06-23 15:18:07.112930', 0, 'Raj2', 'Raj', 'Sharma', 'raj@abc.com', 0, 1, '2021-06-11 07:40:13.798123'),
	(3, 'pbkdf2_sha256$120000$CrcAbtbSo7WN$D6eVqFQd17yuBu59eCXav86ijeWeBD7TXjvFmcuP+3g=', '2021-06-21 15:20:28.769639', 0, 'Sam1', 'Sam', 'White', 'sam@abc.com', 0, 1, '2021-06-12 03:01:59.374314'),
	(4, 'pbkdf2_sha256$120000$gnCrDqJab2L8$V7wyrRgtBVMB7yPG7T/Hs6JGIAyRNO+qSSbcbeBjx7E=', '2021-06-24 15:11:32.779080', 0, 'Anaya4', 'Anaya', 'Khan', 'anaya@abc.com', 0, 1, '2021-06-12 03:04:50.663336'),
	(6, 'pbkdf2_sha256$120000$rn8xZyOIAkoO$F0gLNLpq/eNfi1Mevy0ie27Bh5KsUY9hWO2zDRqAD6Q=', '2021-06-23 15:29:07.771209', 0, 'Mayank6', 'Mayank', 'Sharma', 'mksharma@abc.com', 0, 1, '2021-06-18 06:58:18.549137'),
	(8, 'pbkdf2_sha256$120000$xtMYX7CB81S6$VKfgkFD4dOlvzc4121Wsfl9YCq/72UWqRBamIAV3ulI=', NULL, 0, 'Saloni8', 'Saloni', 'Srivastav', 'saloni@abc.com', 0, 1, '2021-06-25 15:23:25.363157'),
	(9, 'pbkdf2_sha256$120000$IRl3DaZ5WGA1$rYo/sGYJFHYQ/psUdebMHPeNLHQFjtK/njSvn1TcoAw=', NULL, 0, 'Subhash9', 'Subhash', 'Singh', 'subhashs@abc.com', 0, 1, '2021-06-25 15:25:15.082769'),
	(10, 'pbkdf2_sha256$120000$haQtYcZBH1HA$y8FVAhRl/5G6vIZvu5wV7eLl9djq6HC+yt9N1Ssy7nw=', NULL, 0, 'Raja10', 'Raja', 'Mukund Kumar', 'mukukumar@abc.com', 0, 1, '2021-06-25 15:27:21.064457');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;

-- Dumping structure for table urbanservice.auth_user_groups
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_user_groups: ~0 rows (approximately)
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;

-- Dumping structure for table urbanservice.auth_user_user_permissions
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.auth_user_user_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;

-- Dumping structure for table urbanservice.django_admin_log
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.django_admin_log: ~0 rows (approximately)
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;

-- Dumping structure for table urbanservice.django_content_type
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.django_content_type: ~14 rows (approximately)
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
	(1, 'admin', 'logentry'),
	(3, 'auth', 'group'),
	(2, 'auth', 'permission'),
	(4, 'auth', 'user'),
	(5, 'contenttypes', 'contenttype'),
	(15, 'owner', 'offer'),
	(17, 'partner', 'accountsummary'),
	(16, 'partner', 'workrequest'),
	(7, 'serviceondemand', 'cart'),
	(8, 'serviceondemand', 'category'),
	(9, 'serviceondemand', 'orderplan'),
	(10, 'serviceondemand', 'orders'),
	(11, 'serviceondemand', 'partners'),
	(12, 'serviceondemand', 'serviceplans'),
	(13, 'serviceondemand', 'services'),
	(14, 'serviceondemand', 'userprofile'),
	(6, 'sessions', 'session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;

-- Dumping structure for table urbanservice.django_migrations
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.django_migrations: ~18 rows (approximately)
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
	(1, 'contenttypes', '0001_initial', '2021-06-09 13:31:41.168068'),
	(2, 'auth', '0001_initial', '2021-06-09 13:31:42.756892'),
	(3, 'admin', '0001_initial', '2021-06-09 13:31:43.356354'),
	(4, 'admin', '0002_logentry_remove_auto_add', '2021-06-09 13:31:43.367406'),
	(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-06-09 13:31:43.379105'),
	(6, 'contenttypes', '0002_remove_content_type_name', '2021-06-09 13:31:43.554046'),
	(7, 'auth', '0002_alter_permission_name_max_length', '2021-06-09 13:31:43.673613'),
	(8, 'auth', '0003_alter_user_email_max_length', '2021-06-09 13:31:43.710189'),
	(9, 'auth', '0004_alter_user_username_opts', '2021-06-09 13:31:43.724212'),
	(10, 'auth', '0005_alter_user_last_login_null', '2021-06-09 13:31:43.818559'),
	(11, 'auth', '0006_require_contenttypes_0002', '2021-06-09 13:31:43.826637'),
	(12, 'auth', '0007_alter_validators_add_error_messages', '2021-06-09 13:31:43.840810'),
	(13, 'auth', '0008_alter_user_username_max_length', '2021-06-09 13:31:44.119948'),
	(14, 'auth', '0009_alter_user_last_name_max_length', '2021-06-09 13:31:44.454582'),
	(15, 'serviceondemand', '0001_initial', '2021-06-09 13:31:47.755779'),
	(16, 'serviceondemand', '0002_auto_20210609_1856', '2021-06-09 13:31:48.346893'),
	(17, 'serviceondemand', '0003_auto_20210609_1856', '2021-06-09 13:31:48.902742'),
	(18, 'sessions', '0001_initial', '2021-06-09 13:31:49.183596'),
	(19, 'serviceondemand', '0004_orders_date_of_service', '2021-06-11 07:57:28.146330'),
	(20, 'serviceondemand', '0005_userprofile_datejoined', '2021-06-11 12:19:26.386529'),
	(21, 'owner', '0001_initial', '2021-06-12 04:33:00.543494'),
	(22, 'serviceondemand', '0006_orders_status', '2021-06-18 13:51:57.359175'),
	(23, 'serviceondemand', '0007_auto_20210618_1952', '2021-06-18 14:22:04.770456'),
	(24, 'partner', '0001_initial', '2021-06-18 14:45:12.830363'),
	(25, 'serviceondemand', '0008_orders_partner', '2021-06-19 09:35:21.789709'),
	(26, 'partner', '0002_accountsummary', '2021-06-19 09:35:22.197371'),
	(27, 'partner', '0003_auto_20210619_1621', '2021-06-19 10:51:58.840869');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;

-- Dumping structure for table urbanservice.django_session
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.django_session: ~2 rows (approximately)
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
	('4z1gohmrooq6zmm3zupw88l1msrx4r3s', 'MTVhOTA2N2MzMDY2ZjBhZjQwZTI5YTJkN2FhYWFmNDViMDgzODJiZjp7Il9hdXRoX3VzZXJfaWQiOiI2IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkZTMyN2NjZjg3YjM1NDFjNGJlMjMwZjQ0ZjIwNjVmMDMxODE1MDhhIn0=', '2021-07-07 11:30:30.904237'),
	('e0tp51hex4gqigd56x0pokyf0xanmyzx', 'YzNmZTRkYzAyNDUzMWZlMTczMGEzMTE0M2VkYmM1NjkyNzNmZjA4Mzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkMGVlYzhlNzkwZjQwY2VhMmYzZDE4ZDQ2MWQyMjY4MDUwODE1MzBjIn0=', '2021-07-09 15:27:31.357941'),
	('tdq10n20szzosfa2gnb77ngvljsnguh8', 'NjM0MTYzYWQzN2YyOGIwOTc5MGIxM2ZhYWUzNmU5YzA2MzFmODVjNzp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYTM0NmI4YTYzNzVkYTU0NjY1ZWRjNGFhYzlhMGU2YmJiYzYyNDExIn0=', '2021-07-08 15:11:32.788093');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;

-- Dumping structure for table urbanservice.owner_offer
CREATE TABLE IF NOT EXISTS `owner_offer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `desc` varchar(50) NOT NULL,
  `img` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.owner_offer: ~4 rows (approximately)
/*!40000 ALTER TABLE `owner_offer` DISABLE KEYS */;
INSERT INTO `owner_offer` (`id`, `name`, `desc`, `img`) VALUES
	(2, 'ICICI Bank Offers', 'Upto 25% Off', 'offer/icici_card.jpg'),
	(3, 'Massage Therapy For Men', 'Starts @ Rs. 99', 'offer/mens_full_body.png'),
	(4, 'Car Cleaning Service', 'Starts @ Rs. 259', 'offer/car_wash.jpg'),
	(5, 'House Painters', 'Flat 20% OFF', 'offer/Painter.jpg');
/*!40000 ALTER TABLE `owner_offer` ENABLE KEYS */;

-- Dumping structure for table urbanservice.partner_accountsummary
CREATE TABLE IF NOT EXISTS `partner_accountsummary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `workdone` int NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `partner_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_accountsumma_partner_id_4a67efc2_fk_serviceon` (`partner_id`),
  CONSTRAINT `partner_accountsumma_partner_id_4a67efc2_fk_serviceon` FOREIGN KEY (`partner_id`) REFERENCES `serviceondemand_partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.partner_accountsummary: ~0 rows (approximately)
/*!40000 ALTER TABLE `partner_accountsummary` DISABLE KEYS */;
INSERT INTO `partner_accountsummary` (`id`, `workdone`, `balance`, `partner_id`) VALUES
	(1, 8, 3500.00, 1);
/*!40000 ALTER TABLE `partner_accountsummary` ENABLE KEYS */;

-- Dumping structure for table urbanservice.partner_workrequest
CREATE TABLE IF NOT EXISTS `partner_workrequest` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId_id` int NOT NULL,
  `partner_id` int NOT NULL,
  `servicePlan_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_workrequest_orderId_id_7d7777bb_fk_serviceon` (`orderId_id`),
  KEY `partner_workrequest_partner_id_6116a423_fk_serviceon` (`partner_id`),
  KEY `partner_workrequest_servicePlan_id_3eb1db6c_fk_serviceon` (`servicePlan_id`),
  CONSTRAINT `partner_workrequest_orderId_id_7d7777bb_fk_serviceon` FOREIGN KEY (`orderId_id`) REFERENCES `serviceondemand_orders` (`id`),
  CONSTRAINT `partner_workrequest_partner_id_6116a423_fk_serviceon` FOREIGN KEY (`partner_id`) REFERENCES `serviceondemand_partners` (`id`),
  CONSTRAINT `partner_workrequest_servicePlan_id_3eb1db6c_fk_serviceon` FOREIGN KEY (`servicePlan_id`) REFERENCES `serviceondemand_serviceplans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.partner_workrequest: ~2 rows (approximately)
/*!40000 ALTER TABLE `partner_workrequest` DISABLE KEYS */;
INSERT INTO `partner_workrequest` (`id`, `orderId_id`, `partner_id`, `servicePlan_id`) VALUES
	(19, 38, 1, 8);
/*!40000 ALTER TABLE `partner_workrequest` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_cart
CREATE TABLE IF NOT EXISTS `serviceondemand_cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL,
  `plan_id` int NOT NULL,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serviceondemand_cart_service_id_plan_id_user_id_360e5d78_uniq` (`service_id`,`plan_id`,`user_id`),
  KEY `serviceondemand_cart_plan_id_ce819ecb_fk_serviceon` (`plan_id`),
  KEY `serviceondemand_cart_user_id_0b222b4a_fk_serviceon` (`user_id`),
  CONSTRAINT `serviceondemand_cart_plan_id_ce819ecb_fk_serviceon` FOREIGN KEY (`plan_id`) REFERENCES `serviceondemand_serviceplans` (`id`),
  CONSTRAINT `serviceondemand_cart_service_id_95525b04_fk_serviceon` FOREIGN KEY (`service_id`) REFERENCES `serviceondemand_services` (`id`),
  CONSTRAINT `serviceondemand_cart_user_id_0b222b4a_fk_serviceon` FOREIGN KEY (`user_id`) REFERENCES `serviceondemand_userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_cart: ~0 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceondemand_cart` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_category
CREATE TABLE IF NOT EXISTS `serviceondemand_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceondemand_cate_service_id_a210cec6_fk_serviceon` (`service_id`),
  CONSTRAINT `serviceondemand_cate_service_id_a210cec6_fk_serviceon` FOREIGN KEY (`service_id`) REFERENCES `serviceondemand_services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_category: ~14 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_category` DISABLE KEYS */;
INSERT INTO `serviceondemand_category` (`id`, `name`, `service_id`) VALUES
	(1, 'Repair', 3),
	(2, 'Service', 3),
	(3, 'Installation & Uninstallation', 3),
	(4, 'Haircut', 1),
	(5, 'Beard & Moustache', 1),
	(6, 'Hair Color & care', 1),
	(7, 'Massage Therapy', 1),
	(8, 'Face Care', 1),
	(9, 'Waxing', 2),
	(10, 'Facial & Cleanup', 2),
	(11, 'Bleach & Detan', 2),
	(12, 'Pedicure & Manicure', 2),
	(13, 'Hair Color & Care', 2),
	(14, 'Threading & Massage', 2),
	(15, 'Switch & Socket', 4),
	(16, 'Fans', 4),
	(17, 'Light', 4),
	(18, 'MCB & Fuse', 4),
	(19, 'Inverter & Stabilizers', 4),
	(20, 'Appliance', 4),
	(21, 'Home Painting', 5),
	(22, 'Water Proofing', 5),
	(23, 'Textured Walls', 5),
	(24, 'Enamel Painting', 5);
/*!40000 ALTER TABLE `serviceondemand_category` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_orderplan
CREATE TABLE IF NOT EXISTS `serviceondemand_orderplan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) NOT NULL,
  `order_id` int NOT NULL,
  `serviceplan_id` int NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceondemand_orde_order_id_e812257d_fk_serviceon` (`order_id`),
  KEY `serviceondemand_orde_serviceplan_id_e468c4a1_fk_serviceon` (`serviceplan_id`),
  KEY `serviceondemand_orde_service_id_1d064396_fk_serviceon` (`service_id`),
  CONSTRAINT `serviceondemand_orde_order_id_e812257d_fk_serviceon` FOREIGN KEY (`order_id`) REFERENCES `serviceondemand_orders` (`id`),
  CONSTRAINT `serviceondemand_orde_service_id_1d064396_fk_serviceon` FOREIGN KEY (`service_id`) REFERENCES `serviceondemand_services` (`id`),
  CONSTRAINT `serviceondemand_orde_serviceplan_id_e468c4a1_fk_serviceon` FOREIGN KEY (`serviceplan_id`) REFERENCES `serviceondemand_serviceplans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_orderplan: ~37 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_orderplan` DISABLE KEYS */;
INSERT INTO `serviceondemand_orderplan` (`id`, `price`, `order_id`, `serviceplan_id`, `service_id`) VALUES
	(1, 599.00, 4, 24, 3),
	(2, 1099.00, 5, 11, 2),
	(3, 299.00, 5, 10, 2),
	(4, 1499.00, 6, 25, 3),
	(5, 1299.00, 6, 13, 2),
	(6, 49.00, 6, 9, 2),
	(7, 199.00, 7, 1, 1),
	(8, 599.00, 10, 24, 3),
	(9, 1499.00, 11, 8, 1),
	(10, 299.00, 12, 10, 2),
	(11, 1099.00, 12, 11, 2),
	(12, 1799.00, 13, 12, 2),
	(13, 1099.00, 14, 11, 2),
	(14, 99.00, 15, 6, 1),
	(15, 199.00, 16, 1, 1),
	(16, 99.00, 17, 2, 1),
	(17, 99.00, 18, 3, 1),
	(18, 99.00, 19, 5, 1),
	(19, 199.00, 20, 1, 1),
	(20, 199.00, 21, 1, 1),
	(21, 199.00, 22, 1, 1),
	(22, 199.00, 23, 1, 1),
	(23, 299.00, 24, 7, 1),
	(24, 199.00, 24, 1, 1),
	(25, 1499.00, 25, 8, 1),
	(26, 199.00, 25, 1, 1),
	(27, 99.00, 25, 3, 1),
	(28, 99.00, 26, 2, 1),
	(29, 99.00, 27, 5, 1),
	(30, 199.00, 27, 1, 1),
	(31, 299.00, 28, 7, 1),
	(32, 199.00, 29, 1, 1),
	(33, 99.00, 30, 2, 1),
	(34, 99.00, 31, 6, 1),
	(35, 199.00, 32, 1, 1),
	(36, 99.00, 33, 3, 1),
	(37, 199.00, 34, 4, 1),
	(38, 99.00, 35, 5, 1),
	(39, 299.00, 36, 7, 1),
	(40, 199.00, 36, 1, 1),
	(41, 99.00, 37, 3, 1),
	(42, 1499.00, 38, 8, 1);
/*!40000 ALTER TABLE `serviceondemand_orderplan` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_orders
CREATE TABLE IF NOT EXISTS `serviceondemand_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderID` varchar(16) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `placed_by_id` int NOT NULL,
  `date_of_service` date DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `partner_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderID` (`orderID`),
  KEY `serviceondemand_orde_placed_by_id_b9ff847b_fk_serviceon` (`placed_by_id`),
  KEY `serviceondemand_orde_partner_id_b8282156_fk_serviceon` (`partner_id`),
  CONSTRAINT `serviceondemand_orde_partner_id_b8282156_fk_serviceon` FOREIGN KEY (`partner_id`) REFERENCES `serviceondemand_partners` (`id`),
  CONSTRAINT `serviceondemand_orde_placed_by_id_b9ff847b_fk_serviceon` FOREIGN KEY (`placed_by_id`) REFERENCES `serviceondemand_userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_orders: ~28 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_orders` DISABLE KEYS */;
INSERT INTO `serviceondemand_orders` (`id`, `orderID`, `total_amount`, `date`, `address`, `placed_by_id`, `date_of_service`, `status`, `partner_id`) VALUES
	(4, 'OD20210611000002', 648.00, '2021-06-11', 'Hno 32 Pratuyash Colony, Arera Colony, Bhopal, Madhya Pradesh', 2, '2021-06-12', 'Pending', NULL),
	(5, 'OD20210611000003', 1447.00, '2021-06-11', '75 Prabhu Nagar, Idgah Hills, Bhopal, Madhya Pradesh', 2, '2021-06-15', 'Completed', 1),
	(6, 'OD20210611000004', 2896.00, '2021-06-11', 'Sahitaan Gali, Khatra Mahal ,Shamshaan ke peeche, Mumbai, Maharashtra', 2, '2021-06-16', 'Completed', 1),
	(7, 'OD20210612000000', 287.00, '2021-06-12', 'Hno 32 Pratuyash Colony, Arera Colony, Bhopal, Madhya Pradesh', 2, '2021-06-12', 'Completed', 1),
	(10, 'OD20210613000000', 648.00, '2021-06-13', '75 Prabhu Nagar, Idgah Hills, Bhopal, Madhya Pradesh', 3, '2021-06-15', 'Completed', NULL),
	(11, 'OD20210613000001', 1548.00, '2021-06-13', 'Flat No D-7, Ivory Apartments Phase 2, Bhopal, Madhya Pradesh', 3, '2021-06-16', 'Pending', NULL),
	(12, 'OD20210613000002', 1447.00, '2021-06-13', 'Kaali Chowk, Jahangirabaad, Bhoapl, Madhya Pradesh', 4, '2021-06-13', 'Pending', NULL),
	(13, 'OD20210613000003', 1818.00, '2021-06-13', 'Kaali Chowk, Jahangirabaad, Bhopal, Madhya Pradesh', 4, '2021-06-16', 'Pending', NULL),
	(14, 'OD20210618000000', 1148.00, '2021-06-18', 'xyz abc, pqrs mno, NCR, Delhi', 4, '2021-06-23', 'Pending', NULL),
	(15, 'OD20210618000001', 187.00, '2021-06-18', 'abc, pqrs mno, NCR, Delhi', 4, '2021-06-21', 'Pending', NULL),
	(16, 'OD20210618000002', 287.00, '2021-06-18', 'abc, pqrs mno, NCR, Delhi', 3, '2021-06-23', 'Pending', NULL),
	(17, 'OD20210618000003', 187.00, '2021-06-18', 'abc, pqrs mno, NCR, Delhi', 3, '2021-06-22', 'Pending', NULL),
	(18, 'OD20210618000004', 187.00, '2021-06-18', 'Hno 32 Pratuyash Colony, Arera Colony, Bhopal, Madhya Pradesh', 2, '2021-06-22', 'Pending', NULL),
	(19, 'OD20210618000005', 167.00, '2021-06-18', '75 Prabhu Nagar, Idgah Hills, Bhopal, Madhya Pradesh', 2, '2021-06-22', 'Pending', NULL),
	(20, 'OD20210618000006', 287.00, '2021-06-18', 'Hno 32 Pratuyash Colony, Arera Colony, Bhopal, Madhya Pradesh', 2, '2021-06-21', 'Pending', NULL),
	(21, 'OD20210618000007', 287.00, '2021-06-18', '75 Prabhu Nagar, Idgah Hills, Bhopal, Madhya Pradesh', 2, '2021-06-22', 'Pending', NULL),
	(22, 'OD20210618000008', 287.00, '2021-06-18', 'abc, Arera Colony, NCR, Delhi', 2, '2021-06-18', 'Pending', NULL),
	(23, 'OD20210618000009', 287.00, '2021-06-18', 'abc, Arera Colony, NCR, Delhi', 2, '2021-06-22', 'Pending', NULL),
	(24, 'OD20210618000010', 547.00, '2021-06-18', 'abc, pq, , ', 3, '2021-06-22', 'Pending', NULL),
	(25, 'OD20210618000011', 1846.00, '2021-06-18', 'abc, pq, NCR, Delhi', 3, '2021-06-20', 'Rejected', NULL),
	(26, 'OD20210619000000', 187.00, '2021-06-19', 'Vasant Vihar, South Block, NCR, Delhi', 4, '2021-06-22', 'Completed', 1),
	(27, 'OD20210619000001', 386.00, '2021-06-19', 'Hno 32 Pratuyash Colony, Arera Colony, NCR, Delhi', 3, '2021-06-20', 'Completed', 1),
	(28, 'OD20210619000002', 387.00, '2021-06-19', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-22', 'Completed', 1),
	(29, 'OD20210620000000', 227.00, '2021-06-20', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 3, '2021-06-22', 'Completed', 1),
	(30, 'OD20210622000000', 187.00, '2021-06-22', 'abc, bcd, NCR, Madhya Pradesh', 2, '2021-06-23', 'Completed', 1),
	(31, 'OD20210622000001', 187.00, '2021-06-22', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-24', 'Completed', 1),
	(32, 'OD20210622000002', 287.00, '2021-06-22', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-24', 'Completed', 1),
	(33, 'OD20210622000003', 97.00, '2021-06-22', 'abc, Arera Colony, NCR, Madhya Pradesh', 2, '2021-06-22', 'Completed', 1),
	(34, 'OD20210622000004', 287.00, '2021-06-22', 'Hno 32 Pratuyash Colony, Arera Colony, NCR, Madhya Pradesh', 2, '2021-06-24', 'Completed', 1),
	(35, 'OD20210622000005', 187.00, '2021-06-22', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-25', 'Completed', 1),
	(36, 'OD20210623000000', 547.00, '2021-06-23', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 4, '2021-06-24', 'Completed', 1),
	(37, 'OD20210623000001', 157.00, '2021-06-23', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-26', 'Completed', 1),
	(38, 'OD20210623000002', 1548.00, '2021-06-23', '75 Prabhu Nagar, Idgah Hills, NCR, Madhya Pradesh', 2, '2021-06-25', 'Pending', NULL);
/*!40000 ALTER TABLE `serviceondemand_orders` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_partners
CREATE TABLE IF NOT EXISTS `serviceondemand_partners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `partname` varchar(50) NOT NULL,
  `partemail` varchar(50) NOT NULL,
  `partpswd` varchar(50) NOT NULL,
  `partcontact` varchar(50) NOT NULL,
  `partaddress` varchar(100) NOT NULL,
  `partimg` varchar(100) NOT NULL,
  `completed_service` int NOT NULL,
  `rating` decimal(5,1) NOT NULL,
  `aadharNo` varchar(14) NOT NULL,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceondemand_part_service_id_8170ed35_fk_serviceon` (`service_id`),
  KEY `serviceondemand_part_user_id_74e3b457_fk_serviceon` (`user_id`),
  CONSTRAINT `serviceondemand_part_service_id_8170ed35_fk_serviceon` FOREIGN KEY (`service_id`) REFERENCES `serviceondemand_services` (`id`),
  CONSTRAINT `serviceondemand_part_user_id_74e3b457_fk_serviceon` FOREIGN KEY (`user_id`) REFERENCES `serviceondemand_userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_partners: ~1 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_partners` DISABLE KEYS */;
INSERT INTO `serviceondemand_partners` (`id`, `partname`, `partemail`, `partpswd`, `partcontact`, `partaddress`, `partimg`, `completed_service`, `rating`, `aadharNo`, `service_id`, `user_id`, `city`, `state`) VALUES
	(1, 'Mayank Sharma', 'mksharma@abc.com', '1234', '8885559674', 'Vasant Vihar, Delhi', 'partnerimg/user_HWfle6E.jpg', 15, 0.0, '963577894456', 1, 6, 'NCR', 'Delhi'),
	(3, 'Saloni Srivastav', 'saloni@abc.com', '1234', '9988565764', 'Flat 32, Block 2, New Heights Apartment, East Borivali', 'partnerimg/women_salon.jpg', 0, 0.0, '945678124569', 2, 8, 'Mumbai', 'Maharashtra'),
	(4, 'Subhash Singh', 'subhashs@abc.com', '1234', '7788997756', 'Hno 74, Priyanka Colony, Arera hills', 'partnerimg/paint_user.png', 0, 0.0, '778844567985', 5, 9, 'Bhopal', 'Madhya Pradesh'),
	(5, 'Raja Mukund Kumar', 'mukukumar@abc.com', '1234', '8978456878', 'Hno 12, Gandhi Colony', 'partnerimg/elec_user.jpg', 0, 0.0, '885544776699', 4, 10, 'Indore', 'Madhya Pradesh');
/*!40000 ALTER TABLE `serviceondemand_partners` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_serviceplans
CREATE TABLE IF NOT EXISTS `serviceondemand_serviceplans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `planname` varchar(50) NOT NULL,
  `planprice` decimal(10,2) NOT NULL,
  `planimg` varchar(100) NOT NULL,
  `cat_id` int NOT NULL,
  `service_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceondemand_serv_cat_id_923db38b_fk_serviceon` (`cat_id`),
  KEY `serviceondemand_serv_service_id_6122e06e_fk_serviceon` (`service_id`),
  CONSTRAINT `serviceondemand_serv_cat_id_923db38b_fk_serviceon` FOREIGN KEY (`cat_id`) REFERENCES `serviceondemand_category` (`id`),
  CONSTRAINT `serviceondemand_serv_service_id_6122e06e_fk_serviceon` FOREIGN KEY (`service_id`) REFERENCES `serviceondemand_services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_serviceplans: ~25 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_serviceplans` DISABLE KEYS */;
INSERT INTO `serviceondemand_serviceplans` (`id`, `planname`, `planprice`, `planimg`, `cat_id`, `service_id`) VALUES
	(1, 'Hair Cutting', 199.00, 'plans/Men_Hair_cut.jpg', 4, 1),
	(2, 'Beard Grooming & Trimming', 99.00, 'plans/Men_beard_grooming.jpg', 5, 1),
	(3, 'Clean Shaving', 99.00, 'plans/Men_clean_shave.jpg', 5, 1),
	(4, 'Hair Coloring', 199.00, 'plans/Men_hair_color.jpg', 6, 1),
	(5, 'Head Massage', 99.00, 'plans/Men_head_massage.jpg', 7, 1),
	(6, 'Neck & Shoulders Massage', 99.00, 'plans/Men_nexk_massage.jpg', 7, 1),
	(7, 'D-Tan Facial', 299.00, 'plans/Men_dtan-facial.jpg', 8, 1),
	(8, 'Groom Facial', 1499.00, 'plans/Men_groom_facial.jpg', 8, 1),
	(9, 'Underarms Waxing', 49.00, 'plans/under_arm_waxing.jpg', 9, 2),
	(10, 'Leg Waxing', 299.00, 'plans/legs_waxing.jpg', 9, 2),
	(11, 'Full Body Waxing', 1099.00, 'plans/full_body_waxing.jpg', 9, 2),
	(12, 'O3+ Power Brightening Facial', 1799.00, 'plans/O3_facial.jpg', 10, 2),
	(13, 'Golden Pearl Facial', 1299.00, 'plans/golden_pearl_facial.jpg', 10, 2),
	(14, 'Bridal Facial', 2499.00, 'plans/bridal_facial.jpg', 10, 2),
	(15, 'D-Tan Facial', 299.00, 'plans/dtan_facial.jpg', 11, 2),
	(16, 'Bleach', 299.00, 'plans/bleach.jpg', 11, 2),
	(17, 'Pedicure', 599.00, 'plans/pedicure.jpg', 12, 2),
	(18, 'Manicure', 499.00, 'plans/manicure.jpg', 12, 2),
	(19, 'Hair Coloring', 199.00, 'plans/hair_coloring.jpg', 13, 2),
	(20, 'Face Wax', 99.00, 'plans/face_waxing.jpg', 14, 2),
	(21, 'Threading', 29.00, 'plans/threading.jpg', 14, 2),
	(22, 'Head Massage', 99.00, 'plans/head_massage.jpg', 13, 2),
	(23, 'Air Filter Repair', 349.00, 'plans/AC_Air_Filter.jpg', 1, 3),
	(24, 'Split AC Servicing', 599.00, 'plans/AC_Servicing.jpg', 2, 3),
	(25, 'Split Up AC Installation', 1499.00, 'plans/AC_Installation.jpg', 3, 3),
	(26, 'Split Up AC Uninstallation', 649.00, 'plans/AC_Installation_fEtWXr8.jpg', 3, 3),
	(27, 'AC Switch Box Installation', 299.00, 'plans/acswitchbox.png', 15, 4),
	(28, 'Switch Board Installation', 249.00, 'plans/switch_repair.jpg', 15, 4),
	(29, 'Switch Board Repair', 199.00, 'plans/switchboard_installation.jpg', 15, 4),
	(30, 'Celling Fan Regulator Replacement', 79.00, 'plans/FanRegulator.jpg', 16, 4),
	(31, 'Celling Fan Installation', 329.00, 'plans/celing_fan_installation.jpeg', 16, 4),
	(32, 'Fan Repair', 169.00, 'plans/fan_repair.jpg', 16, 4),
	(33, 'Bulb Holder Installation', 100.00, 'plans/bulb_holder_installation.jpeg', 17, 4),
	(34, 'Tubelight Installation', 100.00, 'plans/tubelight_installation.jpg', 17, 4),
	(35, '3 Phase Changeover Switch Replacement', 319.00, 'plans/3phase_changeover.jpg', 18, 4),
	(36, 'Fuse Replacement', 49.00, 'plans/fuse_replacement.png', 18, 4),
	(37, 'MCB Installation & Replace', 129.00, 'plans/mcb_installation.jpg', 18, 4),
	(38, 'Single Battery Inverter Installation', 399.00, 'plans/single_bat_invertor_installation.jpg', 19, 4),
	(39, 'Double Battery Inverter Installation', 499.00, 'plans/double_bat_installation.png', 19, 4),
	(40, 'Stabilizers Installation', 169.00, 'plans/stabilizers.png', 19, 4),
	(41, 'Geyser Installation & Uninstallation', 419.00, 'plans/gyzer_installation.jpg', 20, 4),
	(42, 'Television Installation', 499.00, 'plans/tv_installation.jpg', 20, 4),
	(43, 'Air Cooler Servicing', 349.00, 'plans/air_cooler_service.jpg', 20, 4),
	(44, '10 x 10 ft. (x4 walls)', 5499.00, 'plans/10x10wall.jpg', 21, 5),
	(45, '20 x 10 ft. (x4 walls)', 6599.00, 'plans/20x10wall.jpeg', 21, 5),
	(46, '30 x 10 ft. (x4 walls)', 9999.00, 'plans/30x10.jpg', 21, 5),
	(47, 'Water Proofing', 7299.00, 'plans/water_proofing.jpg', 22, 5),
	(48, 'Textured Wall Paint (10 x 10)', 7490.00, 'plans/textured10x10.jpg', 23, 5),
	(49, 'Textured Wall Paint (20 x 10)', 8499.00, 'plans/textured20x10.jpg', 23, 5),
	(50, 'Door Paint', 2099.00, 'plans/Enameldoorpaint.jpeg', 24, 5),
	(51, 'Window Frame Paint', 899.00, 'plans/Enamel_window_paint.jpeg', 24, 5),
	(52, 'Front Gate Paint', 949.00, 'plans/enamen_gate.jpg', 24, 5);
/*!40000 ALTER TABLE `serviceondemand_serviceplans` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_services
CREATE TABLE IF NOT EXISTS `serviceondemand_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `servicename` varchar(50) NOT NULL,
  `serviceimg` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_services: ~6 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_services` DISABLE KEYS */;
INSERT INTO `serviceondemand_services` (`id`, `servicename`, `serviceimg`) VALUES
	(1, 'Salon For Men', 'serviceimg/male.png'),
	(2, 'Salon For Women', 'serviceimg/femlae.png'),
	(3, 'AC Services & Repair', 'serviceimg/AC.png'),
	(4, 'Electrician', 'serviceimg/electrician.png'),
	(5, 'Painters', 'serviceimg/paint.png'),
	(6, 'Plumbers', 'serviceimg/tap.png');
/*!40000 ALTER TABLE `serviceondemand_services` ENABLE KEYS */;

-- Dumping structure for table urbanservice.serviceondemand_userprofile
CREATE TABLE IF NOT EXISTS `serviceondemand_userprofile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) NOT NULL,
  `user_contact` varchar(15) NOT NULL,
  `uspoints` int NOT NULL,
  `user_id` int NOT NULL,
  `dateJoined` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceondemand_userprofile_user_id_6d7a7767_fk_auth_user_id` (`user_id`),
  CONSTRAINT `serviceondemand_userprofile_user_id_6d7a7767_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table urbanservice.serviceondemand_userprofile: ~6 rows (approximately)
/*!40000 ALTER TABLE `serviceondemand_userprofile` DISABLE KEYS */;
INSERT INTO `serviceondemand_userprofile` (`id`, `user_type`, `user_contact`, `uspoints`, `user_id`, `dateJoined`) VALUES
	(1, 'Admin', '7799884561', 0, 1, '2021-06-11'),
	(2, 'Customer', '8589697465', 20, 2, '2021-06-11'),
	(3, 'Customer', '7766445589', 10, 3, '2021-06-12'),
	(4, 'Customer', '8899457612', 50, 4, '2021-06-12'),
	(6, 'Partner', '8885559674', 5006, 6, '2021-06-18'),
	(8, 'Partner', '9988565764', 0, 8, '2021-06-25'),
	(9, 'Partner', '7788997756', 0, 9, '2021-06-25'),
	(10, 'Partner', '8978456878', 0, 10, '2021-06-25');
/*!40000 ALTER TABLE `serviceondemand_userprofile` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
