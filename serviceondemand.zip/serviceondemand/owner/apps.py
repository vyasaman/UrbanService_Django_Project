from django.apps import AppConfig


class OwnerConfig(AppConfig):
    name = 'owner'
