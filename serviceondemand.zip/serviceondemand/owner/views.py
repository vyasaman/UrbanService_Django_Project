from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from serviceondemand.models import UserProfile, Services, Partners, ServicePlans, Category, Cart, Orders, OrderPlan
from time import sleep
from .models import offer
from django.contrib import messages
from datetime import datetime
import calendar
# Create your views here.


@login_required(login_url='/')
def home(request):
    servonj = Services.objects.all().order_by('servicename')
    offerobj = offer.objects.all()
    data = {
        'service': servonj,
        'offer': offerobj,
    }
    return render(request, 'admin.html', data)


@login_required(login_url='/')
def manage(request, service):
    # for managing subscribed users
    if service == 'users':
        x = datetime.now()
        userobj = []
        user_count = []
        a = x.month

        monthNames = [calendar.month_name[i] for i in range(1, a+1)]
        user_profile = UserProfile.objects.filter(user_type='Customer')
        for i in range(1, a+1):

            user_count.append(UserProfile.objects.filter(
                dateJoined__month=str(i)).count())

        for i in user_profile:
            userobj.append(User.objects.get(id=i.user_id))

        print(user_count, monthNames)

        data = {
            'data': {'userobj': userobj, 'upobj': user_profile, 'ucnt': user_count, 'monthname': monthNames}
        }

        return render(request, 'adminManage.html', data)

    # for managing the employees
    elif service == 'uspartner':

        partner = Partners.objects.all()

        data = {
            'data': {'partobj': partner}
        }

        return render(request, 'adminManage.html', data)

    # for managing the services and plans
    elif service == 'manage':

        service = Services.objects.all()

        data = {
            'data': {'service': service}
        }

        return render(request, 'adminManage.html', data)

    # for Sales and Profit Section
    elif service == 'sales':
        orderobj = []
        x = datetime.now()
        ordobj = []

        for i in range(1, x.month+1):
            orderobj.append(Orders.objects.filter(date__month=str(i)).count)

        serv = Services.objects.all()
        oplan = []
        for i in serv:
            oplan.append(OrderPlan.objects.filter(service=i).count())

        print(oplan)

        data = {
            'data': {'sales': service},
            'order': orderobj,
            'service': serv,
            'servsales': oplan,
        }

        return render(request, 'adminManage.html', data)

    # Offers Section
    elif service == 'offer':
        if request.method == 'POST':
            if 'offerbtn' in request.POST:
                name = request.POST['name']
                desc = request.POST['desc']
                img = request.FILES['img']

                new_offer = offer(name=name, desc=desc, img=img)
                new_offer.save()
                return redirect('/admin/manageservices/offer/')

        offobj = offer.objects.all()
        data = {
            'data': {'offer': offobj}
        }
        return render(request, 'adminManage.html', data)

    elif service == 'updateoffer':
        if request.method == 'POST':
            if 'update' in request.POST:
                name = request.POST['name']
                desc = request.POST['desc']
                img = request.FILES['img']
                select = request.POST['offerSelect']

                ofbj = offer.objects.filter(id=int(select))
                ofbj.update(name=name, img=img, desc=desc)

        offobj = offer.objects.all()
        data = {
            'data': {'updateoffer': offobj}
        }
        return render(request, 'adminManage.html', data)

    # for adding new service
    else:
        if request.method == 'POST':
            servname = request.POST['servname']
            servimg = request.FILES['serviceimg']

            serviceobj = Services(servicename=servname, serviceimg=servimg)
            serviceobj.save()
            sleep(2)

            return redirect('/admin/manageservices/addservice/',)

        data = {
            'data': None
        }
        return render(request, 'adminManage.html', data)


def remove_data(request, model, id):
    if model == 'customer':
        u = User.objects.get(id=id)
        up = UserProfile.objects.get(user=u)
        up.delete()
        u.delete()

        return redirect('/admin/manageservices/users/')

    elif model == 'partner':
        part = Partners.objects.get(id=id)
        up = UserProfile.objects.get(id=part.user_id)
        u = User.objects.get(id=up.user_id)
        part.delete()
        up.delete()
        u.delete()

        return redirect('/admin/manageservices/uspartner/')

    elif model == 'service':
        serv = Services.objects.get(id=id)
        serv.delete()
        return redirect('/admin/manageservices/manage/')

    elif model == 'ServicePlans':
        serv = ServicePlans.objects.get(id=id)
        serv.delete()
        return redirect('/admin/manageservices/manage/')

    elif model == 'cart':
        userobj = UserProfile.objects.get(id=request.user.id)
        c = Cart.objects.get(plan=id, user=userobj)
        c.delete()
        return redirect('/customer/cart/')

    elif model == 'offer':
        offobj = offer.objects.get(id=id)
        offobj.delete()

        return redirect('/admin/manageservices/offer/')


@login_required(login_url='/')
def managePlans(request, id, tabs):
    serv = Services.objects.get(id=id)
    planobj = ServicePlans.objects.filter(service=serv)
    partobj = Partners.objects.filter(service=serv)
    catobj = Category.objects.all()

    if request.method == 'POST':

        if 'add' in request.POST:
            pname = request.POST['pname']
            pprice = request.POST['pprice']
            planpic = request.FILES['pimg']
            category = request.POST['pcat']
            try:
                cobj = Category.objects.get(id=int(category))
                addplan = ServicePlans(
                    planname=pname, planprice=pprice, planimg=planpic, service=serv, cat=cobj)
                addplan.save()
                messages.success(request, 'Added Successfully')
            except:
                messages.error(request, 'Adding Failed')
            return redirect('managePlan', id=id, tabs=tabs)

        elif 'update' in request.POST:
            tabs = 'All_Plans'
            pname = request.POST['pname']
            pprice = request.POST['pprice']
            planid = request.POST['select']
            splans = ServicePlans.objects.filter(id=int(planid))
            if pname == pprice == None or pname == pprice == '' or pname == pprice == ' ':
                messages.error(request, 'Updation Failed')
                return redirect('managePlan', id=id, tabs=tabs)

            elif pprice == None or pprice == '' or pprice == ' ':
                splans.update(planname=pname)
                messages.success(request, 'Updated Successfully')
                return redirect('managePlan', id=id, tabs=tabs)

            elif pname == None or pname == '' or pname == ' ':
                splans.update(planprice=pprice)
                messages.success(request, 'Updated Successfully')
                return redirect('managePlan', id=id, tabs=tabs)

            else:
                splans.update(planname=pname, planprice=pprice)
                messages.success(request, 'Updated Successfully')
                return redirect('managePlan', id=id, tabs=tabs)

    data = {
        'tabs': tabs,
        'id': id,
        'planData': planobj,
        'member': partobj,
        'category': catobj
    }
    return render(request, 'plans.html', data)


def selectPlan(request):

    return render(request, 'selectPlans.html', {'tab': 'admin.html'})
