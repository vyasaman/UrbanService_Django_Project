from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.home),
    path('manageservices/<str:service>/', views.manage),
    path('remove/<str:model>/<int:id>/', views.remove_data),
    path('manageplan/<int:id>/<str:tabs>/',
         views.managePlans, name='managePlan'),
    path('selectPlan/', views.selectPlan, name='select_plan'),
]
