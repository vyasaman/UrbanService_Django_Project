from django.urls import path
from . import views
urlpatterns = [
    path('dashboard/', views.home),
    path('selectPlan/<int:id>/', views.selectPlan, name='select_plan'),
    path('addtocart/<int:ID>/<int:id>/', views.addToCart),
    path('cart/', views.viewCart),
    path('<str:tabs>/', views.profile),


]
