from django.shortcuts import render, redirect
from django.http import HttpResponse
from serviceondemand.models import Services, Category, UserProfile, ServicePlans, OrderPlan, Orders, Cart, Partners
from django.contrib import messages
from owner.models import offer
from partner.models import WorkRequest
from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.core.mail import send_mail
from django.conf import settings

# Create your views here.


@login_required(login_url='/')
def home(request):
    servonj = Services.objects.all().order_by('servicename')
    userobj = UserProfile.objects.get(id=request.user.id)
    cartLenObj = Cart.objects.filter(user=userobj).count()
    offerobj = offer.objects.all()
    data = {
        'service': servonj,
        'len': cartLenObj,
        'offer': offerobj,
    }
    return render(request, 'login.html', data)


# profile section
@login_required(login_url='/')
def profile(request, tabs):
    userobj = User.objects.get(id=request.user.id)
    userprofile = UserProfile.objects.get(user=userobj)
    cartLenObj = Cart.objects.filter(user=userprofile).count()
    order = Orders.objects.filter(placed_by=userprofile).order_by(
        '-date', '-date_of_service')

    oplan = []
    for i in order:
        oplan.append(OrderPlan.objects.filter(order=i))

    data = {
        'user': userobj,
        'userprofile': userprofile,
        'len': cartLenObj,
        'orders': order,
        'oplan': oplan,
        'tab': tabs,

    }

    return render(request, "profile.html", data)


def selectPlan(request, id):
    serviceobj = Services.objects.get(id=id)

    # Login from selecting Page
    if request.method == 'POST':
        if 'searchBarButton' in request.POST:
            search = request.POST['searchBar']

        elif 'loginButton' in request.POST:
            mailid = request.POST['email']
            pswd = request.POST['pswd']
            u = authenticate(username=User.objects.get(
                email=mailid), password=pswd)
            user_type = UserProfile.objects.get(user=u.id)
            if u:
                login(request, u)
                if user_type.user_type == 'Admin':
                    return redirect('/admin/dashboard/')
                elif user_type.user_type == 'Customer':
                    return redirect('select_plan', id=id)
                elif user_type.user_type == 'Partner':
                    return redirect('/partner/dashboard/')
            else:
                return HttpResponse('<h1>404</h1')

        elif 'regesterButton' in request.POST:

            fname = request.POST['fname']
            lname = request.POST['lname']
            uname = request.POST['uname']
            email = request.POST['email']
            pswd = request.POST['pswd']
            contact_no = request.POST['mob']

            userobj = User(first_name=fname, last_name=lname, username=uname,
                           email=email, password=make_password(pswd))
            userobj.save()

            user_profile = UserProfile(
                user_contact=contact_no, user_id=userobj.id)
            user_profile.save()

            # Automatic Login after Registration
            u = authenticate(username=User.objects.get(
                email=email), password=pswd)

            if u:
                login(request, u)
                if user_profile.user_type == 'Admin':
                    return redirect('/admin/dashboard/')
                elif user_profile.user_type == 'Customer':
                    return redirect('select_plan', id=id)
                elif user_profile.user_type == 'Partner':
                    return redirect('/partner/dashboard/')
            else:
                return HttpResponse('<h1>404</h1')
            return redirect('/')

    splan = ServicePlans.objects.filter(service_id=serviceobj)
    catobj = Category.objects.filter(service=serviceobj)
    try:
        userobj = UserProfile.objects.get(id=request.user.id)
        cartLenObj = Cart.objects.filter(user=userobj).count()
        data = {
            'len': cartLenObj,
            'tab': 'login.html',
            'plans': splan,
            'category': catobj,
            'ID': id
        }
    except:
        data = {
            'len': 0,
            'plans': splan,
            'category': catobj,
            'tab': 'index.html',
            'ID': id
        }
    return render(request, 'selectPlans.html', data)

# adding to cart section


@login_required(login_url='/')
def addToCart(request, ID, id):
    planobj = ServicePlans.objects.get(id=int(id))
    userobj = UserProfile.objects.get(id=request.user.id)
    servobj = Services.objects.get(id=planobj.service_id)
    try:
        cartobj = Cart(plan=planobj, service=servobj,
                       user=userobj, price=planobj.planprice)
        cartobj.save()
        messages.success(request, 'Added to Your Bucket.')
    except:
        messages.error(request, 'Already In Your Bucket.')

    return redirect('select_plan', id=ID)

# Cart Page


@login_required(login_url='/')
def viewCart(request):

    userobj = UserProfile.objects.get(id=request.user.id)
    cartLenObj = Cart.objects.filter(user=userobj).count()
    cartObj = Cart.objects.filter(user=userobj)

    plan = []
    cost = 0

    for i in cartObj:
        plan.append(ServicePlans.objects.get(id=i.plan_id))
        cost += i.price

    catobj = []
    for i in plan:
        catobj.append(Category.objects.get(id=i.cat_id))

    if request.method == 'POST':
        if 'check' in request.POST:
            date = request.POST['serviceDate']
            line1 = request.POST['line1']
            line2 = request.POST['line2']
            city = request.POST['city']
            state = request.POST['state']
            netAmt = request.POST['netamt']
            points = request.POST['uspay']
            fullAddress = line1+', '+line2+', '+city+', '+state

            uobj = UserProfile.objects.get(id=request.user.id)

            orderobj = Orders(orderID=createOrderId(), date_of_service=date, total_amount=netAmt,
                              address=fullAddress, placed_by=uobj)
            orderobj.save()
            prod = []
            for i in plan:
                oplan = OrderPlan(price=i.planprice, order=orderobj, serviceplan=ServicePlans.objects.get(
                    id=i.id), service=Services.objects.get(id=i.service_id))
                oplan.save()
                prod.append(ServicePlans.objects.get(id=i.id).planname)

            cartobj = Cart.objects.filter(user=uobj)
            cartObj.delete()

            uobj = UserProfile.objects.filter(id=request.user.id)
            uobj.update(uspoints=int(points))
            for i in uobj:
                temp = i.uspoints
                temp += 10
                uobj.update(uspoints=temp)

            partobj = Partners.objects.filter(city=city)
            orderlist = OrderPlan.objects.filter(order=orderobj)

            for i in partobj:
                for j in orderlist:
                    if i.service == j.service:
                        workreq = WorkRequest(
                            orderId=orderobj, servicePlan=ServicePlans.objects.get(id=int(j.serviceplan_id)), partner=i)
                        workreq.save()

            messages.success(request, 'Order Placed')

            return redirect('/customer/dashboard/')

    userproobj = UserProfile.objects.get(id=request.user.id)

    data = {

        'cat': catobj,
        'len': cartLenObj,
        'cart': cartObj,
        'plan': plan,
        'price': cost,
        'points': userproobj.uspoints
    }
    return render(request, 'cart.html', data)


def createOrderId():

    ordcount = Orders.objects.latest('id')
    orderid = 'OD'
    oid = None
    n = datetime.now()

    if int(ordcount.orderID[2:6]) == n.year and int(ordcount.orderID[6:8]) == n.month and int(ordcount.orderID[8:10]) == n.day:
        oid = int(ordcount.orderID[10:])+1
    else:
        oid = 0
    l = 6-len(str(oid))
    oid = (l*'0')+str(oid)
    if n.month < 10:
        if n.day < 10:
            orderid = orderid+str(n.year)+'0' + \
                str(n.month) + '0'+str(n.day)+str(oid)
        else:
            orderid = orderid+str(n.year)+'0' + \
                str(n.month)+str(n.day)+str(oid)
    else:
        if n.day < 10:
            orderid = orderid+str(n.year)+'0' + \
                str(n.month) + '0'+str(n.day)+str(oid)
        else:
            orderid = orderid+str(n.year)+'0' + \
                str(n.month)+str(n.day)+str(oid)

    return orderid
